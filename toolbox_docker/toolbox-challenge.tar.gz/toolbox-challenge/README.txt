To run this project you must install PHP7. Make sure the php sqlite module is installed/enabled.
Run the following within this folder:
php -S localhost:8080

Then go to the site in your browser: http://localhost:8080/
