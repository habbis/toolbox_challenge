    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="../assets/css/bootstrap.css" type="text/css" media="screen" />
    <link rel="stylesheet" href="../assets/css/style.css" type="text/css" media="screen" />

    <link rel="shortcut icon" href="../assets/img/favicon.ico">
