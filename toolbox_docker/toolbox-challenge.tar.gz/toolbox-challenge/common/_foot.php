    <footer class="py-5 bg-dark fixed-bottom">
        <div class="container">
            <p class="m-0 text-center text-white">Delivered by [YOUR NAME]</p>
        </div>
    </footer>

    <script src="../assets/js/jquery-3.4.1.js" type="text/javascript"></script>
    <script src="../assets/js/bootstrap.bundle.js" type="text/javascript"></script>
    <script src="../assets/js/script.js" type="text/javascript"></script>
